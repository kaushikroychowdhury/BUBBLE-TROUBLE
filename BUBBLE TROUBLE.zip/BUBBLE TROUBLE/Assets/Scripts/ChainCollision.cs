﻿using UnityEngine;
using UnityEngine.UI;

public class ChainCollision : MonoBehaviour {

    public Text scoreText ;
    private float i = 0f;

	void OnTriggerEnter2D (Collider2D col)
    {
        Chain.IsFired = false;

        if (col.tag == "Ball")
        {
            scoreText.text = (++i).ToString("0");

            col.GetComponent<Ball>().Split();
        }
    }
}
