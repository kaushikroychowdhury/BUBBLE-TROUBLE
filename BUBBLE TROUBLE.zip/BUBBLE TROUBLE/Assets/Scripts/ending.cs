﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ending : MonoBehaviour {

    public Text score;

    public void end()
    {
        if (score.text == "62")
        {
            Application.Quit();
        }
    }
}
